<?php

namespace App\Models;
use CodeIgniter\Model;

class StockModel extends Model
{
    protected $table = 'stock';
    protected $primaryKey = 'id';
    protected $allowedFields = ['quantite_dispo', 'date_mise_a_jour', 'produit_id'];


public function getProductNameAndImage($produitId)
{
    $produitModel = new ProduitModel();
    $produit = $produitModel->find($produitId);

    return [
        'nom' => $produit ? $produit['nom'] : 'Non défini',
        'image_url' => $produit ? $produit['image_url'] : '',
    ];
}

public function getStockByProduct($produitId)
{
    return $this->where('produit_id', $produitId)->first();
}

}
