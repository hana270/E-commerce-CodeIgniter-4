<?php

namespace App\Models;

use CodeIgniter\Model;

class CartModel extends Model
{
    protected $table = 'panier';
    protected $primaryKey = 'id';
    protected $allowedFields = ['montant_total', 'date_creation', 'produit_id', 'quantite'];

    public function getCartItemsWithDetails()
    {
        return $this->db->table('panier')
            ->join('produit', 'panier.produit_id = produit.id')
            ->select('panier.id, montant_total, date_creation, panier.produit_id, quantite, produit.prix, produit.nom, produit.image_url, produit.prix')
            ->get()
            ->getResultArray();
    }

    public function addToCart($cartData)
    {
        return $this->insert($cartData);
    }

    public function removeFromCart($produit_id)
    {
        return $this->where('produit_id', $produit_id)->delete();
    }

    public function getOrCreateCartId()
    {
        $cartId = session('client_cart_id');
    
        if (!$cartId) {
            $cartData = [
                'montant_total' => 0,
                'date_creation' => date('Y-m-d H:i:s'),
                'produit_id' => null,
                'quantite' => 0,
            ];
    
            // Insérer un nouveau record dans la table 'panier'
            $this->insert($cartData);
    
            // Récupérer l'ID inséré
            $cartId = $this->db->insertID();
    
            // Définir la variable de session 'client_cart_id'
            session()->set('client_cart_id', $cartId);
        }
    
        return $cartId;
    }
    
    // Dans le modèle CartModel
    public function emptyCart($client_cart_id)
    {
        return $this->where('id', $client_cart_id)->delete();
    }
 
    public function calculateTotalPrice($cart_items)
    {
        $totalPrice = 0;

        foreach ($cart_items as $cart_item) {
            $productTotal = $cart_item['prix'] * $cart_item['quantite'];
            $totalPrice += $productTotal;
        }

        return $totalPrice;
    }
}
