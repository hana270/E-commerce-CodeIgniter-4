<?php

namespace App\Models;

use CodeIgniter\Model;

class CommandeProduitModel extends Model
{
    protected $table = 'commande_produit';
    protected $primaryKey = 'id';
    protected $allowedFields = ['commande_id', 'produit_id', 'quantite'];


}
