<?php

namespace App\Models;

use CodeIgniter\Model;

class ProduitModel extends Model
{
    protected $table = 'produit';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nom', 'description', 'prix', 'reference', 'categorie_id', 'image_url', 'marque_id'];

    public function getMarqueName($marqueId)
    {
        $marqueModel = new MarqueModel();
        $marque = $marqueModel->find($marqueId);

        return $marque ? $marque['nom'] : 'Non défini';
    }

    public function getCategorieName($categorieId)
    {
        $categorieModel = new CategorieModel();
        $categorie = $categorieModel->find($categorieId);

        return $categorie ? $categorie['nom'] : 'Non défini';
    }

    public function getAllProduits()
    {
        return $this->findAll();
    }

    public function searchProducts($searchQuery)
    {
         $this->like('nom', $searchQuery);
        return $this->findAll();
    }
    
    public function filterProductsByBrands($selectedBrands)
    {
        $this->join('marque', 'marque.id = produit.marque_id');
        $this->select('produit.*, marque.nom as marque_nom');
        $this->whereIn('marque.id', $selectedBrands);
    return $this->findAll();
    }

    public function getAvis($produit_id)
    {
        return $this->db->table('avis')
                        ->where('produit_id', $produit_id)
                        ->get()
                        ->getResultArray();
    }
    
}
