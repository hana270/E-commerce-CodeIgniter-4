<?php

namespace App\Models;

use CodeIgniter\Model;

class ProduitModel extends Model
{
    protected $table = 'produit';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nom', 'description', 'prix', 'reference', 'categorie_id', 'image_url', 'marque_id'];

    public function getMarqueName($marqueId)
    {
        $marqueModel = new MarqueModel();
        $marque = $marqueModel->find($marqueId);

        return $marque ? $marque['nom'] : 'Non défini';
    }

    public function getCategorieName($categorieId)
    {
        $categorieModel = new CategorieModel();
        $categorie = $categorieModel->find($categorieId);

        return $categorie ? $categorie['nom'] : 'Non défini';
    }

    public function getAllProduits()
    {
        return $this->findAll();
    }

    public function searchProducts($searchQuery)
    {
        // Utilisez like() pour effectuer la recherche sur le nom
        
        $this->like('nom', $searchQuery);
  
        return $this->findAll();
    }
    
    public function filterProductsByBrands($selectedBrands)
    {
        // Utilisez la méthode join pour lier la table des marques à la table des produits
        $this->join('marque', 'marque.id = produit.marque_id');
    
        // Sélectionnez les champs que vous souhaitez obtenir (ajoutez les champs de marque)
        $this->select('produit.*, marque.nom as marque_nom');
    
        // Ajoutez la condition de recherche sur les marques sélectionnées
        $this->whereIn('marque.id', $selectedBrands);
    
        // Retournez le résultat sous forme de tableau
        return $this->findAll();
    }

   
    public function getAvis($produit_id)
    {
        return $this->db->table('avis')
                        ->where('produit_id', $produit_id)
                        ->get()
                        ->getResultArray();
    }
    
}
