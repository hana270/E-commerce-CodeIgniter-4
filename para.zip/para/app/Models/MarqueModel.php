<?php
namespace App\Models;

use CodeIgniter\Model;

class MarqueModel extends Model
{
    protected $table      = 'marque';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nom', 'description'];

    public function getAllMarques()
    {
        try {
            $marques = $this->findAll();
            print_r($marques);
            return $marques;
        } catch (\Exception $e) {
            die($e->getMessage());
        }
    }
    
}
