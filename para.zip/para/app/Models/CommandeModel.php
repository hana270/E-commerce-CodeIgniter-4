<?php

namespace App\Models;

use CodeIgniter\Model;

class CommandeModel extends Model
{
    protected $table = 'commande';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nom', 'montant_total', 'adresse', 'telephone', 'email', 'code_postal', 'region', 'ville'];

    public function saveCommande($userData)
    {
        $this->insert($userData);
        return $this->insertID();
    }
}
