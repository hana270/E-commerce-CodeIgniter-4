<?php

namespace App\Models;

use CodeIgniter\Model;

class AvisModel extends Model
{
    protected $table = 'avis';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nom_utilisateur', 'contenu', 'produit_id', 'date_creation'];

    protected $useTimestamps = true;
    protected $createdField  = 'date_creation';

    // Inject the ProduitModel in the constructor
    protected $produitModel;

    public function __construct()
    {
        parent::__construct();
        $this->produitModel = new \App\Models\ProduitModel();
    }

    public function getProductName($produit_id)
    {
        $produit = $this->produitModel->find($produit_id);
        return $produit ? $produit['nom'] : 'Non défini';
    }

    // Modify the existing method
    public function getAvisByProduit($produit_id = null)
    {
        if ($produit_id !== null) {
            // Retrieve reviews for a specific product
            $avisList = $this->where('produit_id', $produit_id)->findAll();
        } else {
            // Retrieve all reviews
            $avisList = $this->findAll();
        }

        foreach ($avisList as &$avi) {
            $avi['nom_produit'] = $this->getProductName($avi['produit_id']);
        }

        return $avisList;
    }
}
