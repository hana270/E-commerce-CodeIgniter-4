<?php
namespace App\Controllers;
use CodeIgniter\Controller;

class Auth extends Controller
{
    public function loginAdmin(){
        return view('Admin_template/login');
    }
    
    public function logoutAdmin(){
// Utilisez la classe session de CodeIgniter pour détruire la session
        $session = session();
        $session->destroy();
// Redirect to the login page
return redirect()->to(site_url('login/admin'));
    }

    
public function processLoginAdmin()
{
    $adminUsername = 'admin123';
    $adminPassword = 'admin123';

    $enteredUsername = $this->request->getPost('username');
    $enteredPassword = $this->request->getPost('password');
    $error = ''; //initialisation variable

if ($enteredUsername === $adminUsername && $enteredPassword === $adminPassword) {
// Admin authentication successful
    $_SESSION['admin_authenticated'] = true;
       
//la session est utilisée pour enregistrer le fait 
//que l'administrateur est maintenant authentifié.      
        return redirect()->to('/dashboard');
    }else {
// Authentication failed
        $error = 'Invalide nom ou mot de passe';
    }
// Charger la vue avec l'erreur
        $data['error'] = $error;
        return view('Admin_template/login', $data);
}




}
