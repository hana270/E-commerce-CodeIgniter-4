<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Auth extends Controller
{
    public function loginAdmin()
    {
        return view('Admin_template/login');
    }

    public function logoutAdmin()
    {
        // Utilisez la classe session de CodeIgniter pour détruire la session
        $session = session();
        $session->destroy();

        // Redirect to the login page
        return redirect()->to(site_url('/'));
    }



    public function processLoginAdmin()
    {
        $adminUsername = 'admin123';
        $adminPassword = 'admin123';

        $enteredUsername = $this->request->getPost('username');
        $enteredPassword = $this->request->getPost('password');

        $error = ''; // Initialisez la variable $error

        if ($enteredUsername === $adminUsername && $enteredPassword === $adminPassword) {
            // Admin authentication successful
            $_SESSION['admin_authenticated'] = true;
            return redirect()->to('/dashboard');
        } else {
            // Authentication failed
            $error = 'Invalid username or password';
        }

        // Charger la vue avec l'erreur
        $data['error'] = $error;
        return view('Admin_template/login', $data);
    }

    
}
