<?php
namespace App\Controllers;

use App\Models\CartModel;
use CodeIgniter\Controller;

class Cart extends Controller
{
    public function index()
    {
        $cartModel = new CartModel();
        $data['cart_items'] = $cartModel->getCartItemsWithDetails();
        echo view('Client_template/cart', $data);
    }
       
    public function removeItem($produit_id)
    {
        $model = new CartModel();
        $result = $model->removeFromCart($produit_id);
    
        if ($result) {
             return redirect()->to('cart')->with('success', 'Produit supprimé du panier.');
        } else {
            return redirect()->to('cart')->with('error', 'Erreur lors de la suppression du produit du panier.');
        }
    }
    
    public function clearCart()
    {
        $cartModel = new CartModel();
        $cartId = $cartModel->getOrCreateCartId();
        $cartModel->emptyCart($cartId);
        return redirect()->to('cart');
    }
    
    
    

    
}
?>