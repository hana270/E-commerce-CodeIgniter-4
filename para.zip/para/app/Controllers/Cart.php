<?php
namespace App\Controllers;

use App\Models\CartModel;
use CodeIgniter\Controller;

class Cart extends Controller
{
    public function index()
    {
        // Load the cart model
        $cartModel = new CartModel();

      // Get all items in the cart with associated product details
        $data['cart_items'] = $cartModel->getCartItemsWithDetails();

        // Load the view
        echo view('Client_template/cart', $data);
    }
       
    public function removeItem($produit_id)
    {
        // Charger le modèle du panier
        $model = new CartModel();
        
        // Supprimer l'article de la base de données à l'aide du modèle
        $result = $model->removeFromCart($produit_id);
    
        if ($result) {
            // Suppression réussie
            return redirect()->to('cart')->with('success', 'Produit supprimé du panier.');
        } else {
            // Erreur lors de la suppression
            return redirect()->to('cart')->with('error', 'Erreur lors de la suppression du produit du panier.');
        }
    }
    

}
?>