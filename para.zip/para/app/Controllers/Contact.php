<?php

namespace App\Controllers;

use App\Models\ContactModel;
use CodeIgniter\Controller;

class Contact extends Controller
{
    public function index()
    {
        return view('Client_template/contact');
    }

    public function submit()
    {
        $model = new ContactModel();

        $data = [
            'message' => $this->request->getPost('message'),
            'email' => $this->request->getPost('email'),
            'nom' => $this->request->getPost('nom'),
        ];

        $model->insert($data);

        return redirect()->to('/contact')->with('success', 'Message submitted successfully!');
    }

    // Ajoutez cette méthode à votre contrôleur Contact
public function admin()
{
    $model = new ContactModel();
    
    // Récupérer tous les messages de contact
    $data['messages'] = $model->findAll();

    return view('Admin_template/contact', $data);
}
// Ajoutez cette méthode à votre contrôleur Contact
public function delete($id)
{
    $model = new ContactModel();
    
    // Supprimer le message avec l'ID donné
    $model->delete($id);

    return redirect()->to('/admin/contact')->with('success', 'Message deleted successfully!');
}


}
