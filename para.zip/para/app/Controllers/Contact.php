<?php

namespace App\Controllers;

use App\Models\ContactModel;
use CodeIgniter\Controller;

class Contact extends Controller
{
    public function index()
    {
        return view('Client_template/contact');
    }

    public function submit()
    {
        $model = new ContactModel();

        $data = [
            'message' => $this->request->getPost('message'),
            'email' => $this->request->getPost('email'),
            'nom' => $this->request->getPost('nom'),
        ];

        $model->insert($data);

        return redirect()->to('/contact')->with('success', 'Message soumis avec succès!');
    }

public function admin()
{
    $model = new ContactModel();
    $data['messages'] = $model->findAll();
    return view('Admin_template/contact', $data);
}

public function delete($id)
{
    $model = new ContactModel();
    $model->delete($id);
    return redirect()->to('/admin/contact')->with('success', 'Message deleted successfully!');
}


}
