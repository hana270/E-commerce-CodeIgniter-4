<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\AvisModel;

class Avis extends Controller
{
    public function ajoutAvis()
    {
        // Récupérer les données du formulaire
        $nomUtilisateur = $this->request->getPost('nom_utilisateur');
        $contenuAvis = $this->request->getPost('contenu_avis');
        $produitId = $this->request->getPost('produit_id');

        $avisModel = new AvisModel();
        $avisModel->insert([
            'nom_utilisateur' => $nomUtilisateur,
            'contenu'         => $contenuAvis,
            'produit_id'      => $produitId,
        ]);

        // Récupérer l'ID du produit
        $produitId = $this->request->getPost('produit_id');

        // Rediriger vers la page des détails du produit
        return redirect()->to(base_url("shop/detail/$produitId"))->with('success', 'Avis ajouté avec succès.');
    }
   // Your controller method
   public function index()
{
    $avisModel = new AvisModel();
    $data['avis'] = $avisModel->getAvisByProduit(); // No product ID provided

    return view('Admin_template/avis', $data);
}

   

    public function deleteadmin($id)
    {
        $avisModel = new AvisModel();
        $avisModel->delete($id);

        // Redirect to a relevant page
        return redirect()->to('avis')->with('success', 'Avis supprimé avec succès.');
    }



}
