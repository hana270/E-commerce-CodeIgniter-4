<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\AvisModel;
use Faker\Extension\Helper;

class Avis extends Controller
{
    public function ajoutAvis()
{
    helper('form');

    // Retrieve form data
    $nom_utilisateur = $this->request->getPost('nom_utilisateur');
    $contenu = $this->request->getPost('contenu');
    $produitId = $this->request->getPost('produit_id');

    // Create an AvisModel instance
    $avisModel = new AvisModel();

    // Prepare data for insertion
    $insertData = [
        'nom_utilisateur' => $nom_utilisateur,
        'contenu' => $contenu,
        'produit_id' => $produitId,
        'date_creation' => date('Y-m-d H:i:s'),
    ];

    // Insert the avis into the database
    $avisModel->insertt($insertData);

    // Redirect with a success message
    return redirect()->to(base_url("shop/detail/$produitId"))->with('success', 'Avis ajouté avec succès.');}
    






   // Your controller method
   public function index()
{
    $avisModel = new AvisModel();
    $data['avis'] = $avisModel->getAvisByProduit(); // No product ID provided

    return view('Admin_template/avis', $data);
}

   

    public function deleteadmin($id)
    {
        $avisModel = new AvisModel();
        $avisModel->delete($id);

        // Redirect to a relevant page
        return redirect()->to('avis')->with('success', 'Avis supprimé avec succès.');
    }



}
