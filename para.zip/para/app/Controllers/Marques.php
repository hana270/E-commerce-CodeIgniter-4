<?php
namespace App\Controllers;

use App\Models\MarqueModel;
use CodeIgniter\Controller;

class Marques extends Controller
{
    public function index()
    {
        $model = new MarqueModel();
        $data['marques'] = $model->findAll();
        return view('marques/index', $data);
    }
    public function create()
    {
        return view('marques/create');
    }

    public function store()
    {
        helper('form');
        $model = new MarqueModel();
        $data = [
            'nom' => $this->request->getPost('nom'),
            'description' => $this->request->getPost('description'),
        ];
        $model->insert($data);
        return redirect()->to('/marques');
    }

    public function edit($id)
    {
        $model = new MarqueModel();
        $data['marque'] = $model->find($id);

        return view('marques/edit', $data);
    }

    public function update($id)
    {
        helper('form');
        $model = new MarqueModel();
        $data = [
            'nom' => $this->request->getPost('nom'),
            'description' => $this->request->getPost('description'),
        ];
        $model->update($id, $data);
        return redirect()->to('/marques');
    }

    public function delete($id)
    {
        $model = new MarqueModel();
        $model->delete($id);
        return redirect()->to('/marques');
    }
}
