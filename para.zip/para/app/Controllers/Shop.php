<?php

namespace App\Controllers;
helper('Produits_helper');

use App\Models\ProduitModel;
use App\Models\MarqueModel;
use App\Models\CategorieModel;
use App\Models\CartModel;
use CodeIgniter\Controller;

class Shop extends Controller 
{
public function showShopPage()
{
    try {
        $categoryModel = new CategorieModel();
        $productModel = new ProduitModel();
        $cartModel = new CartModel();
        $marqueModel = new MarqueModel();

        $data['categories'] = $categoryModel->getAllCategories();
        $data['produits'] = $productModel->getAllProduits();
        $data['cart_items'] = $cartModel->getCartItemsWithDetails();

        $cartProductIds = array_column($data['cart_items'], 'produit_id');
        $data['cartProductIds'] = $cartProductIds;

        $data['marques'] = $marqueModel->getAllMarques();

        return view('Client_template/shop', $data);
    } catch (\Exception $e) {
        die($e->getMessage());
    }
}
public function detail($id)
    {
        $produitModel = new ProduitModel();
        $data['produit'] = $produitModel->find($id);

        if (!$data['produit']) {
            // Produit non trouvé, rediriger ou afficher une erreur
            return redirect()->to('/Client_template/shop')->with('error', 'Produit non trouvé.');
        }

        // Récupérer la marque du produit
        $data['marque'] = $this->getMarqueName($data['produit']['marque_id']);

        // Récupérer les avis liés au produit
        $data['avis'] = $produitModel->getAvis($id);

        // Charger la vue des détails du produit
        return view('Client_template/detail', $data);
    }

    // Méthode pour récupérer la marque du produit
    private function getMarqueName($marqueId)
    {
        $marqueModel = new MarqueModel();
        $marque = $marqueModel->find($marqueId);

        return $marque ? $marque['nom'] : 'Non défini';
    }


    public function addToCart($productId)
    {
        // Load the product model
        $produitModel = new ProduitModel();
        
        // Get the product details
        $product = $produitModel->find($productId);
        
        // Load the cart model
        $cartModel = new CartModel();
        
        // Récupérez la quantité souhaitée de l'URL
        $quantity = $this->request->getGet('quantite'); // Utilisez getGet pour récupérer les données de l'URL
        
        // Vérifiez si la quantité est valide (supérieure à 0)
        if ($quantity > 0) {
            // Vérifier si le produit est déjà dans le panier
            $existingCartItem = $cartModel->where('produit_id', $productId)->first();
    
            if ($existingCartItem) {
                // Mettre à jour la quantité et le montant total si le produit est déjà dans le panier
                $newQuantity = $existingCartItem['quantite'] + $quantity;
                $newTotalAmount = $product['prix'] * $newQuantity;
    
                $cartModel->update($existingCartItem['id'], [
                    'quantite' => $newQuantity,
                    'montant_total' => $newTotalAmount,
                ]);
            } else {
                // Ajouter le produit au panier avec la quantité spécifiée
                $cartModel->insert([
                    'montant_total' => $product['prix'] * $quantity,
                    'date_creation' => date('Y-m-d H:i:s'),
                    'produit_id' => $productId,
                    'quantite' => $quantity,
                ]);
            }
    
            // Rediriger vers la page du panier
            return redirect()->to(site_url('cart')); // Utilisez l'URL correcte pour la page du panier
        } else {
            // Rediriger avec un message d'erreur si la quantité n'est pas valide
            return redirect()->back()->with('error', 'Veuillez spécifier une quantité valide.');
        }
    }
    

}    