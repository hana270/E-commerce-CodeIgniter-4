<?php

namespace App\Controllers;
helper('Produits_helper');

use App\Models\ProduitModel;
use App\Models\CategorieModel;
use App\Models\MarqueModel;
use CodeIgniter\Controller;

class Produits extends Controller 
{
 
public function index()
{
    $produitModel = new ProduitModel();
    $data = [
        'produits' => $produitModel->findAll(),
        'produitModel' => $produitModel,
    ];

    helper('Produits_helper');

    return view('produits/index', $data);
}  
public function create()
{
    $categorieModel = new CategorieModel();
    $marqueModel = new MarqueModel();
    $data['categories'] = $categorieModel->findAll();
    $data['marques'] = $marqueModel->findAll(); 
    return view('produits/create', $data);
}
public function store()
{
    helper('form');    
    $produitModel = new ProduitModel();

    $image = $this->request->getFile('image_url');
    if ($image->isValid() && !$image->hasMoved())
    {
            $newName = $image->getRandomName();
            $image->move('public/images/', $newName);

            $data = [
                'nom' => $this->request->getPost('nom'), 
                'description' => $this->request->getPost('description'),
                'prix' => $this->request->getPost('prix'),
                'reference' => $this->request->getPost('reference'),
                'categorie_id' => $this->request->getPost('categorie_id'),
                'image_url' => $newName, 
                'marque_id' => $this->request->getPost('marque_id'), 
            ];
            $produitModel->insert($data);
            return redirect()->to('/produits');
        }
        else
        {
            return redirect()->back()->with('error', 'Veuillez sélectionner un fichier image valide.');
        }
    }
public function edit($id)
{
    $produitModel = new ProduitModel();
    $categorieModel = new CategorieModel();
    $marqueModel = new MarqueModel();
    $data['produit'] = $produitModel->find($id);
    $data['categories'] = $categorieModel->findAll();
    $data['marques'] = $marqueModel->findAll();

    return view('produits/edit', $data);
}

    public function update($id)
    {
        helper(['form', 'url']);
    
        $produitModel = new ProduitModel();
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'description' => $this->request->getPost('description'),
            'prix' => $this->request->getPost('prix'),
            'reference' => $this->request->getPost('reference'),
            'categorie_id' => $this->request->getPost('categorie_id'),
        ];
    
        $image = $this->request->getFile('image_url');
    
        if ($image->isValid() && !$image->hasMoved())
        {
            // Générer un nouveau nom de fichier
            $newName = $image->getRandomName();
    
            // Déplacer le fichier téléchargé vers le dossier des images
            $image->move('public/images/', $newName);
    
            // Mettre à jour le nom de fichier dans les données
            $data['image_url'] = $newName;
        }
    
        $produitModel->update($id, $data);
    
        return redirect()->to('/produits');
    }
    public function delete($id)
    {
        $produitModel = new ProduitModel();
        $produitModel->delete($id);
    
        return redirect()->to('/produits');
    }
    
    

public function shop()
{
    $categoryModel = new CategorieModel();
    $productModel = new ProduitModel();

    $data['categories'] = $categoryModel->getAllCategories();
    $data['produits'] = $productModel->getAllProduits();

    return view('Client_template/shop', $data);
}
public function search()
{
    $searchQuery = $this->request->getGet('search_query');
    $productModel = new ProduitModel();
    $categoryModel = new CategorieModel();

    $data['categories'] = $categoryModel->getAllCategories();
    // Si une requête de recherche est présente, récupérez les produits filtrés
    if ($searchQuery) {
        // Ajoutez les paramètres de tri à la fonction de recherche
        $data['produits'] = $productModel->searchProducts($searchQuery);
    } else {
        // Sinon, récupérez tous les produits
        $data['produits'] = $productModel->getAllProduits();
    }
    return view('Client_template/shop', $data);
}

public function produitCount()
{
    $produitModel = new ProduitModel();
    $produits = $produitModel->findAll();

    $data = [
        'nombreProduits' => count($produits),     
    ];
    return view('clients/index', $data);
}



}