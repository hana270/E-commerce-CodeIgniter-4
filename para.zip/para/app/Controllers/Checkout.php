<?php

namespace App\Controllers;

use App\Models\CommandeModel;
use App\Models\CommandeProduitModel;
use App\Models\CartModel;
use App\Models\ProduitModel;
use App\Models\ClientModel;



class Checkout extends BaseController
{
    public function index()
    {
        $cartModel = new CartModel();
    $cartId = $cartModel->getOrCreateCartId();
    $cart_items = $cartModel->where('id', $cartId)->getCartItemsWithDetails();
        $totalPrice = $cartModel->calculateTotalPrice($cart_items);
        $clientModel = new ClientModel();
        $client_authenticated = session()->has('client_authenticated');
        // Si le client est connecté,récupérer ses informations
        $client_data = [];
        if ($client_authenticated) {
            $client_data = $clientModel->find(session()->get('client_id'));
        }
 return view('Client_template/Checkout', [
            'cart_items' => $cart_items,
            'totalPrice' => $totalPrice,
            'client_authenticated' => $client_authenticated,
            'client_data' => $client_data,
        ]);
    }
  
    public function processOrder()
    {
        $commandeModel = new CommandeModel();
        $commandeProduitModel = new CommandeProduitModel();
        $cartModel = new CartModel();
    // Récupérer l'ID du panier du client
        $cartId = $cartModel->getOrCreateCartId();
    // Récupérer les données du formulaire ou du client connecté
    if ($this->request->getPost('client_authenticated')) {
        $userData = [
            'nom'       => $this->request->getPost('nom'),
            'adresse'   => $this->request->getPost('adresse'),
            'telephone' => $this->request->getPost('telephone'),
            'email'     => $this->request->getPost('email'),
            'code_postal' => $this->request->getPost('code_postal'),
            'region'    => $this->request->getPost('region'),
            'ville'     => $this->request->getPost('ville'),
        ];
    } else {
        $userData = [
            'nom'       => $this->request->getPost('nom'),
            'adresse'   => $this->request->getPost('adresse'),
            'telephone' => $this->request->getPost('telephone'),
            'email'     => $this->request->getPost('email'),
            'code_postal' => $this->request->getPost('code_postal'),
            'region'    => $this->request->getPost('region'),
            'ville'     => $this->request->getPost('ville'),
        ];
    }
    
$commandeId = $commandeModel->saveCommande($userData);
 $cartItems = $cartModel->where('id', $cartId)->getCartItemsWithDetails();
    
// Calculer le montant total
        $totalPrice = $cartModel->calculateTotalPrice($cartItems);
        
        $commandeModel->update($commandeId, ['montant_total' => $totalPrice]);
        
        foreach ($cartItems as $cartItem) {
            $commandeProduitModel->insert([
                'commande_id' => $commandeId,
                'produit_id'  => $cartItem['produit_id'],
                'quantite'    => $cartItem['quantite'],
            ]);
        }
        $cartModel->emptyCart($cartId);
        return redirect()->to('checkout/success');
    }

    public function success()
    {
        return view('Client_template/success'); 
    }

    public function lister()
{   
    $commandeModel = new CommandeModel();
     $commandes = $commandeModel->findAll(); 

    $commandeProduitModel = new CommandeProduitModel();
    foreach ($commandes as &$commande) {
        $produitsCommandes = $commandeProduitModel
            ->select('produit_id, quantite') 
            ->where('commande_id', $commande['id'])
            ->findAll();

        $produits = [];
        foreach ($produitsCommandes as $produitCommande) {    
            $produitModel = new ProduitModel(); 
            $produit = $produitModel->find($produitCommande['produit_id']);

            if ($produit) {
                $produits[] = [
                    'produit_nom' => $produit['nom'],
                    'quantite' => $produitCommande['quantite'],
                ];
            }
        }

        $commande['produits'] = $produits;
    }

    return view('Admin_template/commandes', ['commandes' => $commandes]);
}

public function delete($commandeId)
{
    $commandeModel = new CommandeModel();
    $commandeProduitModel = new CommandeProduitModel();
$produitsCommandes = $commandeProduitModel->where('commande_id', $commandeId)->findAll();
    foreach ($produitsCommandes as $produitCommande) {
        $commandeProduitModel->delete($produitCommande['id']);
    }
    $commandeModel->delete($commandeId);
    return redirect()->to('/commandes');
}
/*
public function dashboard()
    {
        $commandeModel = new CommandeModel();
        $commandes = $commandeModel->findAll(); 
        // Récupérer toutes les commandes depuis la base de données
    
        $commandeProduitModel = new CommandeProduitModel();
    
        // Ajouter les produits à chaque commande
        foreach ($commandes as &$commande) {
            $produitsCommandes = $commandeProduitModel
                ->select('produit_id, quantite') // Sélectionnez les colonnes nécessaires
                ->where('commande_id', $commande['id'])
                ->findAll();
    
            $produits = [];
            foreach ($produitsCommandes as $produitCommande) {
                // Utilisez le modèle de produit pour récupérer les détails du produit
                $produitModel = new ProduitModel(); // Remplacez avec le vrai nom de votre modèle de produit
                $produit = $produitModel->find($produitCommande['produit_id']);
    
                if ($produit) {
                    $produits[] = [
                        'produit_nom' => $produit['nom'],
                        'quantite' => $produitCommande['quantite'],
                    ];
                }
            }
    
            $commande['produits'] = $produits;
        }
// Charger la vue du tableau de bord avec la liste des commandes
        return view('Admin_template/dashboard', ['commandes' => $commandes]);
    }
*/

}