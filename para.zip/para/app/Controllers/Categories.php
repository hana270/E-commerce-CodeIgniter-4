<?php

namespace App\Controllers;
use App\Models\ProduitModel;
use App\Models\CategorieModel; 
use CodeIgniter\Controller;

class Categories extends Controller 
{
    public function index()
    {
        $model = new CategorieModel(); 
        $data['categories'] = $model->findAll(); 
        return view('categories/index', $data); 
    }

    public function create()
    {
        return view('categories/create'); 
    }
    public function store()
    {
        helper('form');
        $model = new CategorieModel(); 
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'description' => $this->request->getPost('description'),
        ];
        $model->insert($data);
        return redirect()->to('/categories');
    }

    public function edit($id)
    {
        $model = new CategorieModel(); 
        $data['categorie'] = $model->find($id);
        return view('categories/edit', $data);
    }

    public function update($id)
    {
        helper('form');

        $model = new CategorieModel();
        $data = [
            'nom' => $this->request->getPost('nom'), 
            'description' => $this->request->getPost('description'),
        ];
        $model->update($id, $data);
        return redirect()->to('/categories'); 
    
    }

    public function delete($id)
{
    $model = new CategorieModel();   
    $model->delete($id);
    return redirect()->to('/categories');
}
public function showProducts($categorie_id)
{
    $produitModel = new ProduitModel();
    $data['produits'] = $produitModel->where('categorie_id', $categorie_id)->findAll();
    return view('categories/show_products', $data); 
  }


}
