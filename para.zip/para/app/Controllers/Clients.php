<?php

namespace App\Controllers;
use App\Models\ProduitModel;
use App\Models\MarqueModel;
use App\Models\ClientModel;
use App\Models\CommandeModel;use App\Models\CategorieModel;use App\Models\ContactModel;
use CodeIgniter\Controller;

class Clients extends Controller
{
    public function login()
    {
        return view('clients/login');
    }

    public function processLogin()
    {
        $model = new ClientModel();
    
        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');
    
        $client = $model->where('email', $email)->first();
    
        if ($client && password_verify($password, $client['password'])) {
            // Authentification réussie
            // Vous pouvez stocker les informations du client en session si nécessaire
            session()->set('client_authenticated', true);
            session()->set('client_id', $client['id']);
            session()->set('client_name', $client['prenom'] . ' ' . $client['nom']);
    
            return redirect()->to('/shop');
        } else {
            // Authentification échouée
            $data['error'] = 'Email ou mot de passe invalide';
            $data['email'] = $email; // Garder la valeur de l'email pour repopuler le champ du formulaire
            return view('clients/login', $data);
        }
    }
    
// Clients.php
// Clients.php
public function index()
{
    $clientModel = new ClientModel();
    $produitModel = new ProduitModel();
    $CommandeModel = new CommandeModel();
    $ContactModel = new ContactModel();

    $data = [
        'clients' => $clientModel->findAll(),
        'nombreProduits' => count($produitModel->findAll()), // Nombre total de produits
        'Commandes' =>count( $CommandeModel->findAll()),
        'messages' => count($ContactModel->findAll()),
    ];
    return view('clients/index', $data);
}



    // ... Autres fonctions du contrôleur ...

    public function register()
    {
        return view('clients/register');
    }

    
public function processRegister()
{
    helper('form');

    $model = new ClientModel();
    $data = [
        'nom' => $this->request->getPost('nom'),
        'email' => $this->request->getPost('email'),
        'prenom' => $this->request->getPost('prenom'),
        'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
        'telephone' => $this->request->getPost('telephone'),
    ];

    // Ajoutez la validation ici
    if (!$model->insert($data)) {
        // Erreur d'insertion, affichez les erreurs
        $data['error'] = $model->errors();
        return view('clients/register', $data);
    }

    // Vous pouvez ajouter un message de succès en session si nécessaire
    $_SESSION['success'] = 'Inscription réussie !';
    return redirect()->to(base_url('clients/login'));

}

public function accueil()
{

    $model = new CategorieModel();
    $data['categories'] = $model->findAll();

 $produitModel = new ProduitModel();
 $data['produits'] = $produitModel->getAllProduits();

    return view('Client_template/index', $data);
}


}
