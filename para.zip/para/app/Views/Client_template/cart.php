<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Bio beauté</title>
    <link rel="shortcut icon" type="image/png" href="/img/titre.png" />

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link  href="<?= base_url('img/favicon.ico') ?>"  rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url('lib/owlcarousel/assets/owl.carousel.min.css') ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url('css/style.css') ?>" rel="stylesheet">
    <style>
    .card-img-top {
        transition: transform 0.3s ease-in-out;
    }

    .card:hover .card-img-top {
        transform: scale(1.1);
    }
</style>
<style>
    body {
        font-family: 'Poppins', sans-serif;
        font-weight: 400;
        background-color: #f8f9fa;
        color: #343a40;
    }
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 1000;
        background-color: #fff;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }

    /* Styles pour les liens de la barre de navigation */
    .navbar-nav .nav-link {
        color: #343a40;
        font-weight: 500;
        margin-right: 20px;
    }
    #header-carousel {
        margin-top: 50px;
    }
/* Style pour le tableau */
#cartTable {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;margin: 10px;
}

#cartTable th, #cartTable td {
    border: 1px solid #ddd;
    padding: 2px;
    text-align: center;
}

#cartTable th {
    background-color: #f2f2f2;
}

/* Style pour l'image dans la première colonne */
#cartTable img {
    max-width: 200px;
    max-height: 200px;
    display: block;
    margin: 0 auto;
}


/* Style pour le bouton de suppression */
.cart-item .btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}

.cart-item .btn-danger:hover {
    background-color: #c82333;
    border-color: #bd2130;
}

/* Centrer le bouton de confirmation */
.text-center.mb-3 a.btn-primary {
    display: block;
    margin: 2px auto;
}

</style>
</head>

<body><!-- Navbar Start -->
<div class="mb-5 custom-container">
    <div class="row border-top px-xl-5">
        <div class="col-lg-9">
            <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <a href="<?= base_url('/accueil') ?>" class="nav-item nav-link">
                            <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">Bio</span>Beauté</h1>
                        </a>
                        </div>
                    <div class="navbar-nav mx-auto py-0"><div class="navbar-nav mr-auto py-0">
                        <a href="<?= base_url('/accueil') ?>" class="nav-item nav-link ">Accueil</a>
                        <a href="<?= base_url('/shop') ?>" class="nav-item nav-link active">Boutique</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="<?= base_url('/cart') ?>" class="dropdown-item active">Panier</a>
                                <a href="<?= base_url('/checkout') ?>" class="dropdown-item">Validation de commande</a>
                            </div>
                        </div>
                        <a href="<?= base_url('/contact') ?>" class="nav-item nav-link">Contact</a>
                        </div>    
                    </div>
                   
                </div>
            </nav>

</div>
    </div>
</div>
<!-- Navbar End -->






            </div>
            
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px;margin-top:90px;">
        <h1 class="font-weight-semi-bold text-uppercase mb-3">Panier d'Achats</h1>

        <div class="d-inline-flex">
    <p class="m-0"><a href="<?= base_url('/accueil') ?>" >Accueil</a></p>
    <p class="m-0 px-2">-</p>
    <p class="m-0">Panier d'Achats</p>
</div>

        </div>
    </div>
    <!-- Page Header End -->
    <?php if (session()->has('success')): ?>
    <div class="alert alert-success">
        <?= session('success') ?>
    </div>
<?php endif; ?>

<!-- Start Cart -->

        <table class="table" id="cartTable">
    <thead>
        <tr>
            <th>Produit</th>
            <th>Prix</th>
            <th>Quantité</th>
            <th>Total</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody class="align-middle">
        <?php if (empty($cart_items)): ?>
            <tr>
                <td colspan="6" class="text-center">Le panier est vide.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($cart_items as $item): ?>
                <tr class="cart-item" data-product-id="<?= $item['id']; ?>">
                    <td class="align-middle">
                        <img src="<?= base_url('public/images/' . $item['image_url']); ?>" alt="<?= $item['nom']; ?>" class="img-thumbnail">
                        <?= $item['nom']; ?> <!-- Display the product name -->
                    </td>
                    <td class="align-middle"><?= $item['prix']; ?></td>

                    <td class="align-middle">
    <input type="number" name="quantite" class="form-control form-control-sm bg-secondary text-center quantity" value="<?= $item['quantite']; ?>" min="1" data-unit-price="<?= $item['prix']; ?>" data-product-id="<?= $item['id']; ?>" disabled>
</td>

                    <td class="align-middle"><?= $item['prix'] * $item['quantite']; ?></td> <!-- Display the total -->
<td class="align-middle">
<a href="<?= site_url("cart/removeItem/{$item['produit_id']}"); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')">
    <i class="fas fa-trash-alt"></i>
</a>

</td>


                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<!-- Bouton pour confirmer les produits -->
<div class="text-center mb-1">
    <a href="<?= base_url("checkout"); ?>" class="btn btn-primary">Confirmer les produits</a>
</div>

<!-- Footer Start -->
<div class="container-fluid bg-secondary  text-black  mt-5 pt-5">
    <div class="row px-xl-5 pt-5">
        <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5 font-weight-bold text-black">
            <a href="#" class="text-decoration-none">
                <h1 class="mb-4 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border border-white px-3 mr-1">Bio</span>Beauté</h1>
            </a>
            <p class="mb-4">Nous vous offrons une expérience unique avec des produits de beauté bio soigneusement sélectionnés. Notre engagement est d'apporter la nature à votre porte, en fournissant des produits qui allient qualité, respect de l'environnement et bien-être.</p>
            <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>14 Rue 6596, Tunis</p>
            <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>biobeaute@gmail.com</p>
            <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>53 942 626</p>
        </div>

        <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5 ">
            <div class="map-container">
                <div class="mb-4">
                    <h5 class="font-weight-bold text-black mb-4">Notre Localisation</h5>
                    <p>Retrouvez-nous au cœur de Tunis, où la nature rencontre la beauté.</p>
                </div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3193.5776523115096!2d10.132490874699512!3d36.828639366097654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12fd33e03e099665%3A0x195578d12947b718!2sparapharmacie%20Bio%20Beaut%C3%A9!5e0!3m2!1sfr!2stn!4v1707133192255!5m2!1sfr!2stn" width="700" height="300" style="border: 2px solid black;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

<!-- Bootstrap JS (or any other dependencies) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>

<!-- Your scripts -->
<script src="<?= base_url('lib/easing/easing.min.js') ?>"></script>
<script src="<?= base_url('lib/owlcarousel/owl.carousel.min.js') ?>"></script>
<script src="<?= base_url('mail/jqBootstrapValidation.min.js') ?>"></script>
<script src="<?= base_url('mail/contact.js') ?>"></script>
<script src="<?= base_url('js/main.js') ?>"></script>

</body>

</html>