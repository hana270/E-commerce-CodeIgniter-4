<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Bio beauté</title>
    <link rel="shortcut icon" type="image/png" href="/img/titre.png" />

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link  href="<?= base_url('img/favicon.ico') ?>"  rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url('lib/owlcarousel/assets/owl.carousel.min.css') ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url('css/style.css') ?>" rel="stylesheet">
    <style>
    body {
        font-family: 'Poppins', sans-serif;
        font-weight: 400;
        background-color: #f8f9fa;
        color: #343a40;
    }
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 1000;
        background-color: #fff;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }

    /* Styles pour les liens de la barre de navigation */
    .navbar-nav .nav-link {
        color: #343a40;
        font-weight: 500;
        margin-right: 20px;
    }
    #header-carousel {
        margin-top: 50px;
    }

</style>

</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row bg-secondary py-2 px-xl-5">
            
                
            </div>
        </div>
        
    <!-- Topbar End -->
<!-- Navbar Start -->
<div class="mb-5 custom-container">
    <div class="row border-top px-xl-5">
        <div class="col-lg-9">
            <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <a href="<?= base_url('/accueil') ?>" class="nav-item nav-link">
                            <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">Bio</span>Beauté</h1>
                        </a>
                 
                    <div class="navbar-nav mx-auto py-0"><div class="navbar-nav mr-auto py-0" style="margin-left:400px;">
                        <a href="<?= base_url('/accueil') ?>" class="nav-item nav-link active">Accueil</a>
                        <a href="<?= base_url('/shop') ?>" class="nav-item nav-link">Boutique</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="<?= base_url('/cart') ?>" class="dropdown-item">Panier</a>
                                <a href="<?= base_url('/checkout') ?>" class="dropdown-item">Validation de commande</a>
                            </div>
                        </div>
                        <a href="<?= base_url('/contact') ?>" class="nav-item nav-link">Contact</a>
                        <a href="<?= base_url('clients/login') ?>" class="nav-item nav-link">Connexion </a>
                        <a href="<?= base_url('clients/register') ?>" class="nav-item nav-link">Inscription</a>
                        
                    </div>
                   
                </div>
            </nav>
<div id="header-carousel" class="carousel slide" data-ride="carousel" style="width: 1250px; margin: 10px; margin-top: 100px;" >
    <div class="carousel-inner">
        <div class="carousel-item active" style="height: 410px;">
            <img class="img-fluid" src="img/carousel-1.jpg" alt="Image">
            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                <div class="p-3" style="max-width: 700px;">
                    <h4 class="text-light text-uppercase font-weight-medium mb-3"></h4>
                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">Découvrez la mode avec nos robes élégantes</h3>
                    <a href="<?= base_url('/shop') ?>"class="btn btn-light py-2 px-3">Découvrir</a>
                </div>
            </div>
        </div>
        <div class="carousel-item" style="height: 410px;">
            <img class="img-fluid" src="img/carousel-2.jpg" alt="Image">
            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                <div class="p-3" style="max-width: 700px;">
                    <h4 class="text-light text-uppercase font-weight-medium mb-3"></h4>
                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">Qualité et prix raisonnables à chaque achat</h3>
                    <a href="<?= base_url('/shop') ?>" class="btn btn-light py-2 px-3">Explorer</a>
                </div>
            </div>
        </div>
    </div>
    <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
        <div class="btn btn-dark" style="width: 45px; height: 45px;">
            <span class="carousel-control-prev-icon mb-n2"></span>
        </div>
    </a>
    <a class="carousel-control-next" href="#header-carousel" data-slide="next">
        <div class="btn btn-dark" style="width: 45px; height: 45px;">
            <span class="carousel-control-next-icon mb-n2"></span>
        </div>
    </a>
</div>
</div>
    </div>
</div>
<!-- Navbar End -->



    <!-- Featured Start -->
    <div class="container-fluid pt-5 custom-container">
        <div class="row px-xl-5 pb-3">
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-check text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">Produit de qualité</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-shipping-fast text-primary m-0 mr-2"></h1>
                    <h5 class="font-weight-semi-bold m-0">Livraison gratuite</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fas fa-exchange-alt text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">Retour sous 14 jours</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-phone-volume text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">Assistance 24h/24 et 7j/7</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Featured End -->

<!-- Offre Start -->
<div class="container-fluid offer pt-5 custom-container">

    <div class="row px-0" style="width: 2600px; margin: 10px;">
        <div class="col-md-6 px-0">
            <div class="position-relative bg-secondary text-center text-md-right text-white offer-card" style="background-image: url('img/svr.jpg'); background-size: cover; background-position: center; height: 100%;">
                <div class="py-5 px-5">
                    <h5 class="text-uppercase text-primary mb-3" style="font-size: 1.5rem; font-weight: bold;color:brown">Prenez soin de votre peau</h5>
                    <h1 class="mb-4 font-weight-bold" style="font-size: 2.5rem;">tout en préservant notre planète</h1>
                    <h3 class="mb-4" style="font-size: 1.8rem;">avec les éco-recharges 1L de SVR</h3>
                    <p style="font-size: 1.2rem;color:brown;">Moins de plastique, plus d'amour pour votre peau & la planète!</p>
                  
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Offre End -->
<!-- Contact Start -->
<div class="container-fluid bg-secondary my-5 custom-container">
    <div class="row justify-content-center align-items-center py-5">
        <div class="col-md-6 col-12 py-5 text-center">
            <div class="mb-4">
                <h2 class="section-title mb-3"><span class="bg-secondary px-2">Nous Contacter</span></h2>
                <p class="lead">Besoin d'aide ou avez-vous des questions ? N'hésitez pas à nous contacter. Nous sommes là pour vous assister.</p>
            </div>
            <form action="<?= site_url('/contact') ?>" method="get">
                <div class="input-group">
                    <!-- Add your form fields here if needed -->
                    <div class="input-group-append" style="margin-left: 280px;">
                        <button type="submit" class="btn btn-primary active">Contacter</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Contact End -->

<!-- Products Start -->
<div class="container-fluid pt-5 custom-container">
    <div class="text-center mb-4">
        <h2 class="section-title px-5"><span class="px-2">Produits Tendances</span></h2>
    </div>
    <div class="row px-xl-5 pb-3">
        <?php $counter = 0; ?>
        <?php foreach ($produits as $product): ?>
            <?php if ($counter < 4): ?>
                <div class="col-lg-3 col-md-6 col-sm-12 mb-4 product-card">
                    <!-- Product Card Start -->
                    <div class="card h-100 border-0 shadow">
                        <img src="<?= base_url('public/images/'.$product['image_url']);?>" alt="<?= htmlspecialchars($product['nom']); ?>" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($product['nom']); ?></h5>
                            <p class="card-text">Prix : <?= htmlspecialchars($product['prix']); ?> dt</p>
                        </div>

                        <div class="card-footer bg-white border-0">
                            <div class="d-flex justify-content-center align-items-center">
                                <a href="<?= site_url("shop/detail/{$product['id']}") ?>" class="btn btn-primary btn-sm">Voir les détails</a>
                            </div>
                        </div>
                    </div>
                    <!-- Product Card End -->
                </div>
                <?php $counter++; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>
<!-- Products End -->
<div class="container-fluid custom-container">
      
            <div class="owl-carousel vendor-carousel">
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-1.jpg') ?>" alt="" class="img-fluid">
                </div>
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-2.jpg') ?>" alt="" class="img-fluid">
                </div>
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-3.jpg') ?>" alt="" class="img-fluid">
                </div>
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-4.jpg') ?>" alt="" class="img-fluid">
                </div>
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-5.jpg') ?>" alt="" class="img-fluid">
                </div>
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-6.jpg') ?>" alt="" class="img-fluid">
                </div>
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-7.jpg') ?>" alt="" class="img-fluid">
                </div>
                <div class="vendor-item border p-4">
                    <img src="<?= base_url('img/vendor-8.jpg') ?>" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Vendor End -->

<!-- Footer Start -->
<div class="container-fluid bg-secondary  text-black  mt-5 pt-5">
    <div class="row px-xl-5 pt-5">
        <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5 font-weight-bold text-black">
            <a href="#" class="text-decoration-none">
                <h1 class="mb-4 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border border-white px-3 mr-1">Bio</span>Beauté</h1>
            </a>
            <p class="mb-4">Nous vous offrons une expérience unique avec des produits de beauté bio soigneusement sélectionnés. Notre engagement est d'apporter la nature à votre porte, en fournissant des produits qui allient qualité, respect de l'environnement et bien-être.</p>
            <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>14 Rue 6596, Tunis</p>
            <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>biobeaute@gmail.com</p>
            <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>53 942 626</p>
        </div>

        <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5 ">
            <div class="map-container">
                <div class="mb-4">
                    <h5 class="font-weight-bold text-black mb-4">Notre Localisation</h5>
                    <p>Retrouvez-nous au cœur de Tunis, où la nature rencontre la beauté.</p>
                </div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3193.5776523115096!2d10.132490874699512!3d36.828639366097654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12fd33e03e099665%3A0x195578d12947b718!2sparapharmacie%20Bio%20Beaut%C3%A9!5e0!3m2!1sfr!2stn!4v1707133192255!5m2!1sfr!2stn" width="700" height="300" style="border: 2px solid black;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url('lib/easing/easing.min.js') ?>" ></script>
    <script src="<?= base_url('lib/owlcarousel/owl.carousel.min.js') ?>" ></script>

    <!-- Contact Javascript File -->
    <script src="<?= base_url('mail/jqBootstrapValidation.min.js') ?>" ></script>
    <script src="<?= base_url('mail/contact.js') ?>" ></script>

    <!-- Template Javascript -->
    <script src="<?= base_url('js/main.js') ?>" ></script>
    <!-- Add this to include jQuery from a CDN -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>


</body>

</html>