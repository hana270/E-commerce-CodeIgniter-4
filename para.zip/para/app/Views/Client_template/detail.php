<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8">
    <title>Bio beauté</title>
    <link rel="shortcut icon" type="image/png" href="/img/titre.png" />

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link  href="<?= base_url('img/favicon.ico') ?>"  rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?= base_url('lib/owlcarousel/assets/owl.carousel.min.css') ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?= base_url('css/style.css') ?>" rel="stylesheet">
    <style>
    .card-img-top {
        transition: transform 0.3s ease-in-out;
    }

    .card:hover .card-img-top {
        transform: scale(1.1);
    }
</style>
<style>
    body {
        font-family: 'Poppins', sans-serif;
        font-weight: 400;
        background-color: #f8f9fa;
        color: #343a40;
        margin: 20px;
        padding: 20px;
    }
    .navbar {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 1000;
        background-color: #fff;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }

    .navbar-nav .nav-link {
        color: #343a40;
        font-weight: 500;
        margin-right: 20px;
}
    #header-carousel {
        margin-top: 50px;
    }
</style>
</head>
<body>

<!-- Navbar Start -->
<div class="mb-5 custom-container">
    <div class="row border-top px-xl-5">
        <div class="col-lg-9">
        <nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0">
                
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <a href="<?= base_url('/accueil') ?>" class="nav-item nav-link">
                            <h1 class="m-0 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border px-3 mr-1">Bio</span>Beauté</h1>
                        </a>
                 
                    <div class="navbar-nav mx-auto py-0"><div class="navbar-nav mr-auto py-0" style="margin-left:400px;">
                        <a href="<?= base_url('/accueil') ?>" class="nav-item nav-link ">Accueil</a>  
                        <a href="<?= base_url('/shop') ?>" class="nav-item nav-link active">Boutique</a>   
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu rounded-0 m-0">
                                <a href="<?= base_url('/cart') ?>" class="dropdown-item">Panier</a>
                                <a href="<?= base_url('/checkout') ?>" class="dropdown-item">Validation de commande</a>
                            </div>
                        </div>
                        <a href="<?= base_url('/contact') ?>" class="nav-item nav-link">Contact</a>  
                    </div>
                   
                </div>
            </nav>
              

</div>
    </div>
</div>
<!-- Navbar End -->

            </div>
            
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
    <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px;margin-top:60px;">
       
    <h1 class="font-weight-semi-bold text-uppercase mb-3">Detail </h1>
            <div class="d-inline-flex">
            <p class="m-0"><a href="<?= base_url('/accueil') ?>" >Accueil</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Detail</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->
    <?php if (session()->has('success')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session('success') ?>
        </div>
    <?php endif; ?>
<!-- Shop Detail Start -->
<div class="container-fluid py-5">
    <div class="row px-xl-5">
        <!-- Colonne Image -->
        <div class="col-lg-6 pb-5">
            <img width="80%" src="<?= base_url('public/images/' . $produit['image_url']); ?>" alt="<?= $produit['nom']; ?>" class="img-thumbnail">
        </div>

        <!-- Colonne Détails -->
<div class="col-lg-6 pb-5">
    <!-- Marque du Produit -->
    <div class="mb-4">
        <h6 style="color: black;font-size:medium;font-family:'Courier New', Courier, monospace" >Marque: <span class="font-weight-bold"><?= esc($marque) ?></span></h6>
    </div>

    <!-- Nom du Produit -->
    <h2 class="font-weight-bold text-primary"><?= esc($produit['nom']) ?></h2>

    <!-- Avis Clients -->
    <p class="text-muted"><i class="fas fa-star text-warning"></i> <?= count($avis) ?> avis client</p>

    <!-- Prix -->
    <h3 class="font-weight-semi-bold mb-4"><?= esc(number_format($produit['prix'], 2)) ?> DT</h3>

    <!-- Formulaire Ajout au Panier -->
    <form action="<?= site_url("shop/add-to-cart/{$produit['id']}") ?>" method="get" class="mb-4">
        <div class="input-group">
            <input type="number" name="quantite" class="form-control" value="1" min="1">
            <div class="input-group-append">
                <button type="submit" class="btn btn-primary">Ajouter au panier</button>
            </div>
        </div>
    </form>

    <!-- Référence du Produit -->
    <p class="text-muted">Référence: <span class="font-italic"><?= esc($produit['reference']) ?></span></p>

    <!-- Onglets -->
    <ul class="nav nav-tabs justify-content-center border-secondary mb-4">
        <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#tab-pane-1">Description</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#tab-pane-3">Avis (<?= count($avis) ?>)</a>
        </li>
    </ul>

    <!-- Contenu des Onglets -->
    <div class="tab-content">
        <div class="tab-pane fade show active" id="tab-pane-1">
            <h4 class="mb-3">Description du Produit</h4>
            <p class="text-justify"><?= esc($produit['description']) ?></p>
        </div>
        <div class="tab-pane fade" id="tab-pane-3">
            <h4 class="mb-3">Avis Clients (<?= count($avis) ?>)</h4>

               <!-- Formulaire d'ajout d'avis -->
               <form action="<?= site_url('ajoutAvis') ?>" method="post">
                    <div class="form-group">
                        <label for="nom_utilisateur">Votre nom:</label>
                        <input type="text" name="nom_utilisateur" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="contenu_">Votre avis:</label>
                        <textarea name="contenu" class="form-control" required></textarea>
                    </div>
                   
                    <div class="form-group">
                        <input type="hidden" name="produit_id" value="<?= esc($produit['id']) ?>">
                    </div>
            <button type="submit" class="btn btn-primary">Ajouter votre avis</button>
                </form>



<br><br>

            <!-- Affichage des avis -->
            <div class="mb-4">
                <div class="border p-3">
                    <?php foreach ($avis as $avisItem): ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center">
                                <p class="font-weight-bold"><?= esc($avisItem['nom_utilisateur']) ?></p>
                                <small><?= date('F j, Y, g:i a', strtotime($avisItem['date_creation'])) ?></small>
                            </div>
                            <p class="text-justify"><?= esc($avisItem['contenu']) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Shop Detail End -->


<!-- Footer Start -->
<div class="container-fluid bg-secondary  text-black  mt-5 pt-5">
    <div class="row px-xl-5 pt-5">
        <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5 font-weight-bold text-black">
            <a href="#" class="text-decoration-none">
                <h1 class="mb-4 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border border-white px-3 mr-1">Bio</span>Beauté</h1>
            </a>
            <p class="mb-4">Nous vous offrons une expérience unique avec des produits de beauté bio soigneusement sélectionnés. Notre engagement est d'apporter la nature à votre porte, en fournissant des produits qui allient qualité, respect de l'environnement et bien-être.</p>
            <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>14 Rue 6596, Tunis</p>
            <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>biobeaute@gmail.com</p>
            <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>53 942 626</p>
        </div>

        <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5 ">
            <div class="map-container">
                <div class="mb-4">
                    <h5 class="font-weight-bold text-black mb-4">Notre Localisation</h5>
                    <p>Retrouvez-nous au cœur de Tunis, où la nature rencontre la beauté.</p>
                </div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3193.5776523115096!2d10.132490874699512!3d36.828639366097654!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12fd33e03e099665%3A0x195578d12947b718!2sparapharmacie%20Bio%20Beaut%C3%A9!5e0!3m2!1sfr!2stn!4v1707133192255!5m2!1sfr!2stn" width="700" height="300" style="border: 2px solid black;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url('lib/easing/easing.min.js') ?>"></script>
<script src="<?= base_url('lib/owlcarousel/owl.carousel.min.js') ?>"></script>

   <!-- Contact Javascript File -->
<script src="<?= base_url('mail/jqBootstrapValidation.min.js') ?>"></script>
<script src="<?= base_url('mail/contact.js') ?>"></script>

   
<!-- Template Javascript -->
<script src="<?= base_url('js/main.js') ?>"></script>
</body>

</html>