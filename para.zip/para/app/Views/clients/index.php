<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/feather-icons@4.28.0/dist/feather.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }

        h2, h4 {
            color: #495057;
        }

        .card {
            margin-bottom: 20px;
            border: none;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: scale(1.02);
        }

        .card-title {
            font-size: 18px;
            color: #007bff;
        }

        .card-text {
            font-size: 16px;
            color: #6c757d;
        }

        .alert-info {
            background-color: #d1ecf1;
            color: #0c5460;
            border-color: #bee5eb;
        }

        .table {
            background-color: #ffffff;
        }

        th, td {
            color: #495057;
        }

        .badge-success {
            background-color: #28a745;
        }

        .badge-danger {
            background-color: #dc3545;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row mt-5">
    <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><i data-feather="users"></i> Clients</h5>
                    <p class="card-text">Nombre total : <?= count($clients); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><i data-feather="package"></i> Produits</h5>
            <p class="card-text">Nombre total : <?= $nombreProduits; ?></p>
        </div>
    </div>



        </div>
        <div class="col-md-3">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><i data-feather="shopping-cart"></i> Commandes</h5>
            <p class="card-text">Nombre total : <?= $Commandes; ?></p>
        </div>
    </div>
</div>

<div class="col-md-3">
<div class="card">
<div class="card-body">
            <h5 class="card-title"><i data-feather="message-square"></i> Messages</h5>
            <p class="card-text">Nombre total : <?= $messages; ?></p>
        </div>
    </div>
</div>



    </div>

    <!-- Barre de recherche -->
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Rechercher un client" id="searchClient">
    </div>

    <!-- Tableau des clients -->
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($clients as $client): ?>
            <tr>
                <td><?= $client['id']; ?></td>
                <td><?= $client['nom']; ?></td>
                <td><?= $client['prenom']; ?></td>
                <td><?= $client['email']; ?></td>
                <td><?= $client['telephone']; ?></td>
            
            <td>
                       
                        <a href="<?= site_url("clients/delete//{$client['id']}"); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ?')">Supprimer</a>
                    </td>
                
                </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://unpkg.com/feather-icons@4.28.0/dist/feather.min.js"></script>
<script>
    feather.replace();
</script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>
<script>
    $(document).ready(function() {
        // Activer la recherche en temps réel lors de la saisie dans la barre de recherche
        $('#searchClient').on('input', function() {
            var searchTerm = $(this).val().toLowerCase();
            $('table tbody tr').filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(searchTerm) > -1);
            });
        });
    });
</script>
</body>
</html>
