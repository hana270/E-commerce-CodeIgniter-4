<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Marque</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 50px auto; /* Centrer le conteneur et ajouter de l'espace autour */
        }
        .form-label {
            font-weight: bold;
        }
        .btn {
            border-radius: 5px;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="mb-4" align="center">Modifier une Marque</h2>

    <form action="<?= site_url("/marques/update/{$marque['id']}"); ?>" method="post">
        <div class="mb-3">
            <label for="nom" class="form-label">Nom de la Marque :</label>
            <input type="text" class="form-control" name="nom" value="<?= $marque['nom']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Description de la Marque :</label>
            <textarea class="form-control" name="description" rows="3"><?= $marque['description']; ?></textarea>
        </div>

        <div class="text-center"> <!-- Centrer le bouton -->
            <button type="submit" class="btn btn-outline-success">Modifier</button>
            <a href="<?= site_url('/marques'); ?>" class="btn btn-outline-secondary">Annuler</a>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
