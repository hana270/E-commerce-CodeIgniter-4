<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Marque</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            
            height: 100vh;
        }
        .container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 80%;
        }
        .form-label {
            font-weight: bold;
        }
        .btn {
            border-radius: 5px;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">Ajouter une Marque</h2>

    <!-- Formulaire de création de marque -->
    <form action="<?= site_url('/marques/store'); ?>" method="post">
        <div class="mb-3">
            <label for="nom" class="form-label">Nom de la Marque :</label>
            <input type="text" class="form-control" name="nom" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Description :</label>
            <textarea class="form-control" name="description" rows="3"></textarea>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-outline-success">Ajouter</button>
            <a href="<?= site_url('/marques'); ?>" class="btn btn-outline-secondary">Annuler</a>
        </div>
    </form>
</div>

<!-- Ajouter les scripts Bootstrap (si nécessaire) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
