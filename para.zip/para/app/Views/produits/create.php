<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Ajouter un Produit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .container { background-color: #ffffff; border-radius: 10px; box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); padding: 20px; margin: 50px auto; }
        .form-label { font-weight: bold; }
        .btn { border-radius: 5px; }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center mb-4">Nouveau Produit</h2>
    
    <form action="/produits/store" method="post" enctype="multipart/form-data">
        <div class="row mb-3">
            <div class="col-md-6">
                <label class="form-label">Nom du Produit :</label>
                <input type="text" class="form-control" name="nom" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Prix du Produit :</label>
                <input type="text" class="form-control" name="prix" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Référence du Produit :</label>
            <input type="text" class="form-control" name="reference" pattern="\d{13}" title="La référence doit contenir 13 chiffres" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Catégorie du Produit :</label>
            <select class="form-control" name="categorie_id" required>
                <?php foreach ($categories as $categorie): ?>
                    <option value="<?= $categorie['id']; ?>"><?= $categorie['nom']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Marque du Produit :</label>
            <select class="form-control" name="marque_id" required>
                <?php foreach ($marques as $marque): ?>
                    <option value="<?= $marque['id']; ?>"><?= $marque['nom']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Description du Produit :</label>
            <textarea class="form-control" name="description" rows="2"></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Image du Produit :</label>
            <input type="file" class="form-control" name="image_url" accept="image/*" required>
        </div>

        <div class="text-center">
            <button type="submit" class="btn btn-outline-success">Ajouter</button>
            <a href="<?= site_url('/produits'); ?>" class="btn btn-outline-secondary">Annuler</a>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
