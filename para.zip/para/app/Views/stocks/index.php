<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Stocks</title>
    <!-- Ajouter le lien du CDN Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 10px auto;
        }
        .table img {
            max-width: 100px;
            height: auto;
        }
        .btn {
            border-radius: 5px;
        }
        .table {
            margin-top: 20px; /* Augmenter la marge supérieure */
            margin-bottom: 20px; /* Augmenter la marge inférieure */
        }
        .table thead th,
        .table tbody td {
            padding-left: 15px;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="row mb-4">
        <div class="col-lg-6 col-md-6 col-sm-12">
            <h2 class="text-lg-start text-md-start text-center">Liste des Stocks</h2>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-12 d-flex justify-content-lg-end justify-content-md-end justify-content-center">
            <a href="<?= site_url('/stocks/create'); ?>" class="btn btn-outline-dark">Ajouter un Stock</a>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-hover  table table-bordered">
            <thead class="thead-dark">
                <tr>
                    
                    <th>Quantité disponible</th>
                    <th>Date de mise à jour</th>
                    <th>Produit</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($stocks as $stock) : ?>
                    <tr>
                        
                        <td><?= $stock['quantite_dispo']; ?></td>
                        <td><?= $stock['date_mise_a_jour']; ?></td>
                        <td>
                            <img src="<?= base_url('public/images/' . $stock['image_produit']); ?>" alt="Image du Produit" style="max-width: 50px;">
                            <?= $stock['nom_produit']; ?>
                        </td>
                        <td>
                            <a href="<?= site_url("stocks/edit/{$stock['id']}"); ?>" class="btn btn-outline-warning btn-sm me-2">Modifier</a>
                            <a href="<?= site_url("stocks/delete/{$stock['id']}"); ?>"  class="btn btn-outline-danger btn-sm" onclick="return confirmDelete();">Supprimer</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

<script>
    function confirmDelete() {
        return confirm("Voulez-vous vraiment supprimer ce stock ?");
    }
</script>

</body>
</html>
