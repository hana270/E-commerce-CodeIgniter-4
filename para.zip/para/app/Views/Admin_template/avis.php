<!-- Views/admin/avis/index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Admin - Liste des Avis</title>
    <style>
        body {
            background-color: #f8f9fa;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin-left: -400px;
        }
        .container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 50%;
            margin-top: -300px;
        }
        .btn {
            border-radius: 5px;
        }
       
        .table thead th, .table tbody td {
            padding-left: 15px;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="row mb-4">
        <div class="col-lg-6 col-md-6 col-sm-12">
            <h2 class="text-lg-start text-md-start text-center" >Liste des Avis</h2>
        </div>
    </div>
 
    <table class="table table-striped table-hover   table table-bordered">
        <thead class="thead-dark">
        <tr>
        <th>Nom Utilisateur</th>
        <th>Contenu</th>
        <th>Date de Création</th>
        <th>Nom du Produit</th> 
        <th>Action</th>
    </tr>
        </thead>
        <tbody>
        <?php foreach ($avis as $avi) : ?>
        <tr>
            <td><?= $avi['nom_utilisateur']; ?></td>
            <td><?= $avi['contenu']; ?></td>
            <td><?= $avi['date_creation']; ?></td>
            <td><?= $avi['nom_produit']; ?></td> 
            <td>
                <a href="<?= site_url("avis/delete/{$avi['id']}"); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet avis ?')">Supprimer</a>
            </td>
        </tr>
    <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
