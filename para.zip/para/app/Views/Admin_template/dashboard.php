<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/feather-icons@4.28.0/dist/feather.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            background-color: #ffffff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }

        h2 {
            color: #007bff;
            margin-bottom: 20px;
        }

        .table {
            background-color: #ffffff;
            border: 1px solid #dee2e6;
            margin-top: 20px;
        }

        th, td {
            color: #495057;
            padding: 12px;
            text-align: center;
        }

        .badge-success {
            background-color: #28a745;
        }

        .badge-danger {
            background-color: #dc3545;
        }

        .btn-delete {
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Liste des Commandes</h2>

        <table class="table table-striped table-hover table-bordered">
            <thead class="thead-dark">
                <tr>
                    <th>Nom</th>
                    <th>Montant Total</th>
                    <th>Adresse</th>
                    <th>Téléphone</th>
                    <th>Email</th>
                    <th>Code Postal</th>
                    <th>Région</th>
                    <th>Ville</th>
                    <th>Produits</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($commandes as $commande): ?>
    <tr>
        <td><?= $commande['nom']; ?></td>
        <td><?= $commande['montant_total']; ?></td>
        <td><?= $commande['adresse']; ?></td>
        <td><?= $commande['telephone']; ?></td>
        <td><?= $commande['email']; ?></td>
        <td><?= $commande['code_postal']; ?></td>
        <td><?= $commande['region']; ?></td>
        <td><?= $commande['ville']; ?></td>
        <td>
            <ul>
                <?php foreach ($commande['produits'] as $produit): ?>
                    <li><?= $produit['produit_nom']; ?> x <?= $produit['quantite']; ?></li>
                <?php endforeach; ?>
            </ul>
        </td>
        <td>
            <a href="<?= site_url("commandes/delete/{$commande['id']}"); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirmDelete();">Supprimer</a>
        </td>
    </tr>
<?php endforeach; ?>

            </tbody>
        </table>
    </div>

    <script src="https://unpkg.com/feather-icons@4.28.0/dist/feather.min.js"></script>
    <script>
        feather.replace();
        
        function confirmDelete() {
            return confirm('Êtes-vous sûr de vouloir supprimer cette commande ?');
        }
    </script>

</body>
</html>
