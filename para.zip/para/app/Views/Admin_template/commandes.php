<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Stocks</title>
    <!-- Ajouter le lien du CDN Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 20px;width:2700px;
            
        }
        .table img {
            max-width: 100px;
            height: auto;
        }
        .btn {
            border-radius: 5px;
        }
        .table {
            margin-top: 20px; /* Augmenter la marge supérieure */
            margin-bottom: 20px; /* Augmenter la marge inférieure */
        }
        .table thead th,
        .table tbody td {
            padding-left: 15px;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>
<!-- Admin Commandes Start -->
<div class="container mt-5">
    <div class="row mb-4">
        <div class="col-lg-6 col-md-6 col-sm-1">
            <h2 class="text-lg-start text-md-start text-center">Liste des commandes</h2>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered">
            <thead class="thead-dark">
                <tr>
                   
                    <th>Nom</th>
                    <th>Montant Total</th>
                    <th>Adresse</th>
                    <th>Téléphone</th>
                    <th>Email</th>
                    <th>Code Postal</th>
                    <th>Région</th>
                    <th>Ville</th>
                    <th>Produits</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($commandes as $commande): ?>
    <tr>
        <td><?= $commande['nom']; ?></td>
        <td><?= $commande['montant_total']; ?></td>
        <td><?= $commande['adresse']; ?></td>
        <td><?= $commande['telephone']; ?></td>
        <td><?= $commande['email']; ?></td>
        <td><?= $commande['code_postal']; ?></td>
        <td><?= $commande['region']; ?></td>
        <td><?= $commande['ville']; ?></td>
        <td>
            <ul>
                <?php foreach ($commande['produits'] as $produit): ?>
                    <li><?= $produit['produit_nom']; ?> x <?= $produit['quantite']; ?></li>
                <?php endforeach; ?>
            </ul>
        </td>
        <td>
            <a href="<?= site_url("commandes/delete/{$commande['id']}"); ?>" class="btn btn-outline-danger btn-sm" onclick="return confirmDelete();">Supprimer</a>
        </td>
    </tr>
<?php endforeach; ?>

            </tbody>
        </table>
    </div>
</div>
<!-- Admin Commandes End -->

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

<script>
    function confirmDelete() {
        return confirm("Voulez-vous vraiment supprimer ce stock ?");
    }
</script>

</body>
</html>
