<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Contact Messages</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin: 10px auto;
            margin-left: 20px;
        }
        .table img {
            max-width: 100px;
            height: auto;
        }
        .btn {
            border-radius: 5px;
        }
        .table {
            margin-top: 10px;
            margin-bottom: 10px;
        }
        .table thead th,
        .table tbody td {
            padding-left: 15px;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="text-center mb-4">
        <h2 class="section-title px-5"><span class="px-2"> Contact Messages</span></h2>
    </div>
    <div class="row px-xl-5">
        <div class="col-lg-12 mb-5">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Message</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($messages as $message): ?>
                            <tr>
                               
                                <td><?php echo $message['nom']; ?></td>
                                <td><?php echo $message['email']; ?></td>
                                <td><?php echo $message['message']; ?></td>
                                <td>
    <a href="#" class="btn btn-danger btn-sm" onclick="confirmDelete('<?php echo base_url('/admin/contact/delete/' . $message['id']); ?>')">Delete</a>
</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    function confirmDelete(deleteUrl) {
        if (confirm("Voulez-vous vraiment supprimer ce message ?")) {
            window.location.href = deleteUrl;
        }
    }
</script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-9/reFTGAWKm1Bd/BjNecv9ESw2aHQv1xLXR00m2rKbV4V2cBr4p9tSLqKDO9R5an" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy2Au2a+6QrMIVN6Pj3aLd6D5F+JjPUvXy" crossorigin="anonymous"></script>

</body>
</html>
