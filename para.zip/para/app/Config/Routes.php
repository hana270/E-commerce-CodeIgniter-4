<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('dashboard', 'Home::admin');


// Authentification admin
$routes->get('login/admin', 'Auth::loginAdmin');
$routes->post('login/admin/process', 'Auth::processLoginAdmin');

$routes->get('logout', 'Auth::logoutAdmin');

//client===>
$routes->get('clients', 'Clients::index');
$routes->get('clients/create', 'Clients::create');
$routes->post('clients/store', 'Clients::store');
$routes->get('clients/edit/(:num)', 'Clients::edit/$1');
$routes->post('clients/update/(:num)', 'Clients::update/$1');
$routes->get('clients/delete/(:num)', 'Clients::delete/$1');

$routes->get('clients/login', 'Clients::login');
$routes->post('clients/login', 'Clients::processLogin');
$routes->get('clients/register', 'Clients::register');
$routes->post('clients/register', 'Clients::processRegister');

//Partie Client
$routes->get('/accueil', 'Clients::accueil');

$routes->get('/contact', 'Contact::index');
$routes->post('/contact/submit', 'Contact::submit');
$routes->get('/admin/contact', 'Contact::admin');
$routes->get('/admin/contact/delete/(:num)', 'Contact::delete/$1');

$routes->get('/shop', 'Produits::shop');

$routes->get('/shop', 'Shop::showShopPage');

$routes->get('shop/detail/(:num)', 'Shop::detail/$1');
$routes->get('produits/search', 'Produits::search');
$routes->post('shop/fetchProductsByCategory', 'Shop::fetchProductsByCategory');

$routes->get('cart', 'Cart::index');
$routes->get('shop/add-to-cart/(:num)', 'Shop::addToCart/$1');
$routes->get('cart/removeItem/(:num)', 'Cart::removeItem/$1');

$routes->get('checkout', 'Checkout::index');

$routes->post('checkout/processOrder', 'Checkout::processOrder');
$routes->get('checkout/success', 'Checkout::success');

$routes->get('commandes', 'Checkout::lister');
$routes->get('commandes/delete/(:num)', 'Checkout::delete/$1');

$routes->get('/avis', 'Avis::index');
$routes->get('avis/delete/(:num)', 'Avis::deleteadmin/$1');

$routes->get('admin/dash', 'Checkout::dashboard');

//Avis
$routes->post('ajoutAvis', 'Avis::ajoutAvis');


//categories===>
$routes->get('categories', 'Categories::index');
$routes->get('categories/create', 'Categories::create');
$routes->post('categories/store', 'Categories::store');
$routes->get('categories/edit/(:num)', 'Categories::edit/$1');
$routes->post('categories/update/(:num)', 'Categories::update/$1');
$routes->get('categories/delete/(:num)', 'Categories::delete/$1');
$routes->get('categories/showProducts/(:num)', 'Categories::showProducts/$1');

//Produits===>
$routes->get('produits', 'Produits::index');

$routes->get('produits/create', 'Produits::create');
$routes->post('produits/store', 'Produits::store');

$routes->get('produits/edit/(:num)', 'Produits::edit/$1');
$routes->post('produits/update/(:num)', 'Produits::update/$1');
$routes->get('produits/delete/(:num)', 'Produits::delete/$1');


$routes->post('produits/confirmed-delete/(:num)', 'Produits::confirmedDelete/$1');

//Marques===>
$routes->get('marques', 'Marques::index');
$routes->get('marques/create', 'Marques::create');
$routes->post('marques/store', 'Marques::store');
$routes->get('marques/edit/(:num)', 'Marques::edit/$1');
$routes->post('marques/update/(:num)', 'Marques::update/$1');
$routes->get('marques/delete/(:num)', 'Marques::delete/$1');

///Stocks=====>
    $routes->get('stocks', 'Stocks::index');
    $routes->get('stocks/create', 'Stocks::create');
    $routes->post('stocks/store', 'Stocks::store');
    $routes->get('stocks/edit/(:num)', 'Stocks::edit/$1');
    $routes->post('stocks/update/(:num)', 'Stocks::update/$1');
    $routes->get('stocks/delete/(:num)', 'Stocks::delete/$1');

